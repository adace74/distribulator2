######################################################################
#
# $Id: XMLFileChecker.py,v 1.2 2005/09/10 00:47:03 awd Exp $
#
# (c) Copyright 2004 Orbitz, Inc.  All Rights Reserved.
# Please see the accompanying LICENSE file for license information.
#
######################################################################

# Pydoc comments
"""This class is responsible for pre-checking XML configuration file well-formedness."""

# Version tag
__version__= '$Revision: 1.2 $'[11:-2]

# Standard modules
import logging
import os
import os.path
import sys
import xml.parsers.expat
from glob import glob

# Custom modules
import engine.data.GlobalConfig

######################################################################

class XMLFileChecker:
    """This class is responsible for pre-checking XML configuration file well-formedness."""

    def __init__(self):
        """Constructor."""

        pass

######################################################################

    def check(self, PassedGlobalConfig):
        """This method represents the main entry point into the XML check logic."""

        self._globalConfig = PassedGlobalConfig

        myFilename = self._globalConfig.getAppConfigFile()

        try:
            parser = xml.parsers.expat.ParserCreate()
            parser.ParseFile(open(myFilename, "r"))

        except IOError, (errno, strerror):
            print("ERROR: [Errno %s] %s: %s" % (errno, strerror, myFilename))
            sys.exit(True)

        except Exception, myException:
            print("ERROR: XML configuration file is not well-formed!")
            print("ERROR: %s" % myException)
            sys.exit(True)

######################################################################
